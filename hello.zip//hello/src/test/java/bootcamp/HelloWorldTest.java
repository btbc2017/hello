package bootcamp;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Unit test for simple App.
 */
@RunWith(JUnit4.class)
public class HelloWorldTest {

    @Test
    public void testApp() {
        assertTrue(true);
    }
}
