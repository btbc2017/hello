package bootcamp;

public class HelloWorld {
    public static void main(String... argvs) {
        String name = "Bootcamp";
        System.out.println("Hello " + name + " World!");
    }
}
